# 任务清单 设计说明

## 应用概况

一个深色卡片风格的待办事项清单应用，支持添加、勾选完成、删除任务和顶部统计。（类型：todo）。

## 模块划分

- 入口（HTML 挂载点 / 页面结构）：/index.html
- 应用源码：/src/App.jsx、/src/main.jsx
- 视图组件（每文件一组件）：/src/components/AddTaskForm.jsx、/src/components/ConfirmDialog.jsx、/src/components/StatsBar.jsx、/src/components/TaskItem.jsx、/src/components/TaskList.jsx
- 状态逻辑（hooks）：/src/hooks/useTasks.js
- 纯逻辑（utils，无框架依赖）：/src/utils/taskUtils.js
- 全局样式：/styles/main.css

## 数据流

用户交互触点：

- 输入任务名称后点击添加或按回车键新增任务
- 点击任务项前的复选框切换完成/未完成状态
- 点击删除按钮弹出确认对话框，确认后删除任务
- 页面刷新后任务数据从 localStorage 恢复

交互事件更新状态，状态变化驱动视图渲染，持久化数据写入 localStorage（如适用）。

## 后续演进建议

（占位：可在此记录重构方向、性能优化点与新功能规划。）
