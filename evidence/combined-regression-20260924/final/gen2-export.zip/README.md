# 未命名项目

> 未命名项目：由 Litpp（AI 应用生成平台）生成的 Web 应用。

本项目由 [Litpp](https://litpp.dev)（AI 应用生成平台）生成，导出时间：2026/9/24 22:50:27。

## 运行方式

### 方式一：双击 dist/index.html（最简单）

解压后双击 `dist/index.html`，即可在浏览器中打开应用。
这是平台在导出时生成的浏览器端编译产物（自包含单文件），无需任何构建步骤。
引用 CDN 的外部库（如图表库）需要联网加载。

`dist/vendor/` 下是平台附带的运行时本地副本（react.vendor.js、sucrase.vendor.js），`dist/index.html` 以相对路径引用它们，请保持原目录结构，无需联网即可运行。

### 方式二：源码作为工程起点

源码目录（`index.html`、`src/`、`styles/` 等）是规范的工程起点。
如果应用包含多文件拆分、ES Module 导入或本地数据请求，建议在源码目录用静态服务器运行，
避免 `file://` 协议下的跨域限制：

```bash
# 使用 Node.js（任选其一）
npx serve .
npx http-server .

# 使用 Python
python3 -m http.server 8080
```

然后按提示在浏览器打开（如 http://localhost:3000 或 http://localhost:8080）。

预览由 Litpp 内置沙箱运行；npm 方式需 Node 18+，作为工程起点使用。

## 技术说明

- **框架**：React（经 CDN 以 UMD 方式引入，无需构建）
- **源码入口**：`index.html`
- **可运行产物**：`dist/index.html`（双击即可运行）
- **文件数量**：14 个

## 依赖列表

- React（UI 框架，经 CDN 引入）

## 目录结构

```
.
├── index.html
├── styles/main.css
├── src/utils/taskUtils.js
├── src/hooks/useTasks.js
├── src/components/StatsBar.jsx
├── src/components/AddTaskForm.jsx
├── src/components/TaskItem.jsx
├── src/components/TaskList.jsx
├── src/components/ConfirmDialog.jsx
├── src/App.jsx
├── src/main.jsx
├── README.md
├── DESIGN.md
├── package.json
├── dist/index.html
├── dist/vendor/react.vendor.js
├── dist/vendor/sucrase.vendor.js
└── README.md
```
