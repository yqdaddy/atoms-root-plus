const STORAGE_KEY = 'litpp_tasks';

export function loadTasks() {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (data) {
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.warn('localStorage 读取失败:', e);
  }
  return [];
}

export function saveTasks(tasks) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  } catch (e) {
    console.warn('localStorage 写入失败:', e);
  }
}

export function validateTaskName(value) {
  if (!value || value.trim() === '') return { valid: false, error: '任务不能为空' };
  return { valid: true, value: value.trim() };
}

export function createTask(name) {
  return {
    id: Date.now() + Math.random(),
    text: name,
    completed: false,
  };
}

export function getStats(tasks) {
  const total = tasks.length;
  const completed = tasks.filter(t => t.completed).length;
  return { total, completed };
}
