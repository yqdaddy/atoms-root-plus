import React from 'react';

export default function StatsBar({ tasks }) {
  const total = tasks.length;
  const completed = tasks.filter(t => t.completed).length;

  return (
    <div className="stats-bar">
      <span className="stats-text">
        已完成 <span className="stats-highlight">{completed}</span> / 总数 <strong>{total}</strong>
      </span>
      {total > 0 && (
        <span className="stats-text">
          进度 <span className="stats-highlight">{Math.round((completed / total) * 100)}%</span>
        </span>
      )}
    </div>
  );
}
