import React from 'react';

export default function TaskItem({ task, onToggle, onDelete }) {
  const [isDeleting, setIsDeleting] = React.useState(false);

  function handleDelete() {
    setIsDeleting(true);
    setTimeout(() => onDelete(task.id), 200);
  }

  return (
    <div className={`task-item${isDeleting ? ' removing' : ''}`}>
      <div className="checkbox-wrapper">
        <div
          className={`custom-checkbox ${task.completed ? 'checked' : ''}`}
          onClick={() => onToggle(task.id)}
          role="checkbox"
          aria-checked={task.completed}
          tabIndex={0}
          onKeyDown={(e) => { if (e.key === ' ' || e.key === 'Enter') onToggle(task.id); }}
        />
      </div>
      <span className={`task-text ${task.completed ? 'completed' : ''}`}>
        {task.text}
      </span>
      <button
        className="btn btn-danger"
        onClick={handleDelete}
        aria-label="删除任务"
      >
        ✕
      </button>
    </div>
  );
}
