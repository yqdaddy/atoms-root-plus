import React from 'react';

export default function ConfirmDialog({ message, onConfirm, onCancel }) {
  return (
    <div className="confirm-dialog" onClick={onCancel}>
      <div className="dialog-content" onClick={e => e.stopPropagation()}>
        <h3 className="dialog-title">确认删除</h3>
        <p className="dialog-message">{message}</p>
        <div className="dialog-actions">
          <button className="btn btn-cancel" onClick={onCancel}>取消</button>
          <button className="btn btn-confirm-delete" onClick={onConfirm}>删除</button>
        </div>
      </div>
    </div>
  );
}
