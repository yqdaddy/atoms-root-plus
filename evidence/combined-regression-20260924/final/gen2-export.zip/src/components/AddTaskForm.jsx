import React from 'react';

export default function AddTaskForm({ onAdd }) {
  const [inputValue, setInputValue] = React.useState('');

  function handleSubmit(e) {
    e.preventDefault();
    const task = onAdd(inputValue);
    if (task) setInputValue('');
  }

  function handleChange(e) {
    setInputValue(e.target.value);
  }

  return (
    <form className="add-task-form" onSubmit={handleSubmit}>
      <input
        type="text"
        className="input-field"
        placeholder="添加新任务..."
        value={inputValue}
        onChange={handleChange}
        maxLength={200}
      />
      <button
        type="submit"
        className="btn btn-primary"
        disabled={!inputValue.trim()}
      >
        添加
      </button>
    </form>
  );
}
