import React from 'react';
import { loadTasks, saveTasks, createTask, validateTaskName } from '../utils/taskUtils.js';

export default function useTasks() {
  const [tasks, setTasks] = React.useState(() => loadTasks());

  React.useEffect(() => {
    saveTasks(tasks);
  }, [tasks]);

  function addTask(rawName) {
    const result = validateTaskName(rawName);
    if (!result.valid) return null;
    const newTask = createTask(result.value);
    setTasks(prev => [...prev, newTask]);
    return newTask;
  }

  function toggleTask(id) {
    setTasks(prev => prev.map(task =>
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  }

  function removeTask(id) {
    setTasks(prev => prev.filter(task => task.id !== id));
  }

  return { tasks, addTask, toggleTask, removeTask };
}
