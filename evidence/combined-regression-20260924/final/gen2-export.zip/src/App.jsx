import React from 'react';
import useTasks from './hooks/useTasks.js';
import StatsBar from './components/StatsBar.jsx';
import AddTaskForm from './components/AddTaskForm.jsx';
import TaskList from './components/TaskList.jsx';
import ConfirmDialog from './components/ConfirmDialog.jsx';

export default function App() {
  const { tasks, addTask, toggleTask, removeTask } = useTasks();
  const [deleteTarget, setDeleteTarget] = React.useState(null);

  function handleToggle(id) {
    toggleTask(id);
  }

  function handleDeleteRequest(id) {
    const task = tasks.find(t => t.id === id);
    if (task) {
      setDeleteTarget({ id, text: task.text });
    }
  }

  function handleConfirmDelete() {
    if (deleteTarget) {
      removeTask(deleteTarget.id);
      setDeleteTarget(null);
    }
  }

  function handleCancelDelete() {
    setDeleteTarget(null);
  }

  return (
    <div className="app-container">
      <h1 className="app-title">📋 任务清单</h1>
      <StatsBar tasks={tasks} />
      <AddTaskForm onAdd={addTask} />
      <TaskList
        tasks={tasks}
        onToggle={handleToggle}
        onDelete={handleDeleteRequest}
      />
      {deleteTarget && (
        <ConfirmDialog
          message={`确定要删除「${deleteTarget.text}」吗？`}
          onConfirm={handleConfirmDelete}
          onCancel={handleCancelDelete}
        />
      )}
    </div>
  );
}
